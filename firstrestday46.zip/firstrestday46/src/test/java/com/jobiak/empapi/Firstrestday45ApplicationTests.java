package com.jobiak.empapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Firstrestday45ApplicationTests {

	@Test
	void contextLoads() {
	}

}
