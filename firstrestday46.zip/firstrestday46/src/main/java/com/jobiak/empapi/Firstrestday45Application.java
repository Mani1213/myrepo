package com.jobiak.empapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Firstrestday45Application {

	public static void main(String[] args) {
		SpringApplication.run(Firstrestday45Application.class, args);
	}

}
